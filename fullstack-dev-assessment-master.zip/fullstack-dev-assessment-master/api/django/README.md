# Candidate App

Built with Python 2.7.12, Django 1.10.8. Uses sqlite3.

To get started:

To install dependencies, run `pip install -r requirements.txt`

Run `python manage.py migrate` to create and seed the database.

To start the server, run `python manage.py runserver`